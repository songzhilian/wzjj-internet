CREATE package vio is
 type type_table is table of varchar2(256);
 procedure p_vio_tj_dd( p_tjrqs in varchar2,  p_tjrqz in varchar2, p_bmdm in varchar2,cur_ws  out sys_refcursor);


end vio;

/
