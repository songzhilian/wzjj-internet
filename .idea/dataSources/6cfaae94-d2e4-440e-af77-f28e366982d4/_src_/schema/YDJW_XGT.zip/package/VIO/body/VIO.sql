CREATE package body vio is

 procedure p_vio_tj_dd( p_tjrqs in varchar2,  p_tjrqz in varchar2, p_bmdm in varchar2, cur_ws  out sys_refcursor) is

  begin
     if substr(p_bmdm,5,2)='00' then --320300
      open cur_ws for
      select t0.xzqh, t0.bmdm, t0.bmmc,   nvl(surveil2,0) surveil2, nvl(surveil3,0) surveil3  from
        (select  xzqh,bmdm, bmjc bmmc from acl_dept_dd  where zt='1' ) t0
        --锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select substr(bmdm,1,6) xzqh, count(1) as login
                     from xgt_acl_user_login
                     where dlsj>= to_date(p_tjrqs, 'yyyy-mm-dd') and dlsj< to_date(p_tjrqz, 'yyyy-mm-dd')+1
                     group by substr(bmdm,1,6)) t1  on t0.xzqh =t1.xzqh


        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       --  left join (select acl.f_get_bmdmdd(fxjg) xzqh, count(1) as vio2
       --              from vio_violation_in t
       --              where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and t.zt='2'
       --              group by acl.f_get_bmdmdd(fxjg)) t2  on t0.xzqh =t2.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       --  left join (select acl.f_get_bmdmdd(fxjg) xzqh, count(1) as vio3
       --              from vio_violation_in t
       --              where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and t.zt='3'
       --              group by acl.f_get_bmdmdd(fxjg)) t3  on t0.xzqh =t3.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        -- left join (select acl.f_get_bmdmdd(fxjg) xzqh, count(1) as force2
        --             from vio_force_in t
        --             where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and  substr(pzbh,7,1)='3' and t.zt='2'
        --             group by acl.f_get_bmdmdd(fxjg)) t4  on t0.xzqh =t4.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       -- left join (select acl.f_get_bmdmdd(fxjg) xzqh, count(1) as force3
       --              from xgt_vio_force_in t
         --            where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and  substr(pzbh,7,1)='3' and t.zt='3'
         --            group by acl.f_get_bmdmdd(fxjg)) t5  on t0.xzqh =t5.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select acl.f_get_bmdmdd(cjjg) xzqh, count(1) as surveil2
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and t.zt='2' and ywzl='2'
                     group by acl.f_get_bmdmdd(cjjg)) t6  on t0.xzqh =t6.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select acl.f_get_bmdmdd(cjjg) xzqh, count(1) as surveil3
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and (t.zt is null or t.zt<>'2') and ywzl='2'
                     group by acl.f_get_bmdmdd(cjjg)) t7  on t0.xzqh =t7.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select acl.f_get_bmdmdd(cjjg) xzqh, count(1) as wt2
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and t.zt='2' and ywzl='1'
                     group by acl.f_get_bmdmdd(cjjg)) t16  on t0.xzqh =t16.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select acl.f_get_bmdmdd(cjjg) xzqh, count(1) as wt3
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and (t.zt is null or t.zt<>'2') and ywzl='1'
                     group by acl.f_get_bmdmdd(cjjg)) t17  on t0.xzqh =t17.xzqh

         --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       --  left join (select acl.f_get_bmdmdd(fxjg) xzqh, count(1) as wftzs2
       --              from vio_force_in t
       --              where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and substr(pzbh,7,1)='6' and t.zt='2'
       --              group by acl.f_get_bmdmdd(fxjg)) t8  on t0.xzqh =t8.xzqh

         --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
     --   left join (select acl.f_get_bmdmdd(fxjg) xzqh, count(1) as wftzs3
     --                from vio_force_in t
     --                where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and substr(pzbh,7,1)='6' and t.zt='3'
     --                group by acl.f_get_bmdmdd(fxjg)) t9  on t0.xzqh =t9.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
    --    left join (select acl.f_get_bmdmdd(glbm) xzqh, count(1) as jysg2
    --                 from acd_dutysimple t
    --                  where t.sgfssj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.sgfssj<to_date(p_tjrqz,'yyyy-mm-dd')+1 and zt='2'
    --                  group by acl.f_get_bmdmdd(glbm)) t10 on t0.xzqh=t10.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
     --    left join (select acl.f_get_bmdmdd(glbm) xzqh,count(1) as jysg3
     --                from acd_dutysimple t
     --                 where t.sgfssj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.sgfssj<to_date(p_tjrqz,'yyyy-mm-dd')+1 and zt='3'
     --                 group by acl.f_get_bmdmdd(glbm)) t11 on t0.xzqh=t11.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
      --   left join (select acl.f_get_bmdmdd(cjjg) xzqh,count(1) as sgkc2
      --               from acd_kscl t
      --                where t.sgfssj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.sgfssj<to_date(p_tjrqz,'yyyy-mm-dd')+1
      --               and t.sgqx not in('999999','999996')
      --                group by acl.f_get_bmdmdd(cjjg)) t12 on t0.xzqh=t12.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
     --   left join (select acl.f_get_bmdmdd(cjjg) xzqh,count(1) as sgkc3
     --                from acd_kscl t
     --                 where t.sgfssj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.sgfssj<to_date(p_tjrqz,'yyyy-mm-dd')+1 and zt='3'
     --                 and t.sgqx not in('999999','999996')
     --                 group by acl.f_get_bmdmdd(cjjg)) t13 on t0.xzqh=t13.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
     --   left join(select acl.f_get_bmdmdd(fxjg) xzqh,count(1) as dzjc2
       --             from vio_dzjc_jycl_in t
        --             where t.clsj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.clsj<to_date(p_tjrqz,'yyyy-mm-dd')+1 and zt='2'
         --             group by acl.f_get_bmdmdd(fxjg))t14 on t0.xzqh=t14.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
      --  left join(select acl.f_get_bmdmdd(fxjg) xzqh,count(1) as dzjc3
      --              from vio_dzjc_jycl_in t
      --               where t.clsj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.clsj<to_date(p_tjrqz,'yyyy-mm-dd')+1 and zt ='3'
      --                group by acl.f_get_bmdmdd(fxjg))t15 on t0.xzqh=t15.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
     --   left join (
       -- select acl.f_get_bmdmdd(t1.bmdm) xzqh,count(1) as jcj2 from acl_user t1,
      --  (select zpyhdm from v_jcj_jqxx where ZPSJ>=to_date(p_tjrqs, 'yyyy-mm-dd') and zpsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1
       -- ) t2 where t1.yhdm = t2.zpyhdm group by acl.f_get_bmdmdd(t1.bmdm))t18  on t0.xzqh =t18.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
  --      left join (
  --      select acl.f_get_bmdmdd(t1.bmdm) xzqh,count(1) as jcj3 from acl_user t1,
  --      (select zpyhdm from v_jcj_jqxx where ZPSJ>=to_date(p_tjrqs, 'yyyy-mm-dd') and zpsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1
  --      and qszt='1') t2 where t1.yhdm = t2.zpyhdm group by acl.f_get_bmdmdd(t1.bmdm))t19  on t0.xzqh =t19.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
     --   left join(select acl.f_get_bmdmdd(t2.bmdm) xzqh,count(1) as kklj2
       --             from jcbk_yjxx_tsxx t1,acl_user t2
         --            where t1.tssj>=to_date(p_tjrqs,'yyyy-mm-dd') and t1.tssj<to_date(p_tjrqz,'yyyy-mm-dd')+1
           --          and t1.yhdm = t2.yhdm
             --         group by acl.f_get_bmdmdd(t2.bmdm))t20 on t0.xzqh=t20.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       -- left join(select acl.f_get_bmdmdd(cjjg) xzqh,count(1) as kklj3
         --           from jcbk_yjxx_ljfk t
           --          where t.fksj>=to_date(p_tjrqs,'yyyy-mm-dd') and t.fksj<to_date(p_tjrqz,'yyyy-mm-dd')+1
             --        and ljzt='1'
               --       group by acl.f_get_bmdmdd(cjjg))t21 on t0.xzqh=t21.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       -- left join(select acl.f_get_bmdmdd(t2.bmdm) xzqh,count(1) as zrq2
         --           from xxcj_xxsb t1,acl_user t2
           --          where t1.sbsj>=to_date(p_tjrqs,'yyyy-mm-dd') and t1.sbsj<to_date(p_tjrqz,'yyyy-mm-dd')+1
             --        and t1.xxlx='06' and t1.yhdm=t2.yhdm
               --       group by acl.f_get_bmdmdd(t2.bmdm))t22 on t0.xzqh=t22.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
      --  left join(select acl.f_get_bmdmdd(t2.bmdm) xzqh,count(1) as zrq3
        --            from xxcj_xxsb t1,acl_user t2
          --           where t1.sbsj>=to_date(p_tjrqs,'yyyy-mm-dd') and t1.sbsj<to_date(p_tjrqz,'yyyy-mm-dd')+1
            --         and t1.xxlx='02' and t1.yhdm=t2.yhdm
              --        group by acl.f_get_bmdmdd(t2.bmdm))t23 on t0.xzqh=t23.xzqh

         --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        --left join(select acl.f_get_bmdmdd(t2.bmdm) xzqh,count(1) as zrq4
          --          from xxcj_xxsb t1,acl_user t2
          --           where t1.sbsj>=to_date(p_tjrqs,'yyyy-mm-dd') and t1.sbsj<to_date(p_tjrqz,'yyyy-mm-dd')+1
          --           and t1.xxlx='03' and t1.yhdm=t2.yhdm
          --           group by acl.f_get_bmdmdd(t2.bmdm))t24 on t0.xzqh=t24.xzqh

         --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join(select acl.f_get_bmdmdd(t2.bmdm) xzqh,count(1) as zrq5
                    from xxcj_yhpc t1,acl_user t2
                     where t1.fxsj>=to_date(p_tjrqs,'yyyy-mm-dd') and t1.fxsj<to_date(p_tjrqz,'yyyy-mm-dd')+1
                     and t1.yhdm=t2.yhdm
                     group by acl.f_get_bmdmdd(t2.bmdm))t25 on t0.xzqh=t25.xzqh;

         --锟斤拷锟斤拷锟斤拷锟斤拷

    else
      open cur_ws for
      select t0.xzqh, t0.bmdm, t0.bmmc, nvl(surveil2,0) surveil2, nvl(surveil3,0) surveil3 from
        (select  xzqh,bmdm, bmjc bmmc from acl_dept_dd  where zt='1' and xzqh=acl.f_get_bmdmdd(p_bmdm)) t0
        --锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select substr(bmdm,1,6) xzqh, count(1) as login
                     from xgt_acl_user_login
                     where dlsj>= to_date(p_tjrqs, 'yyyy-mm-dd') and dlsj< to_date(p_tjrqz, 'yyyy-mm-dd')+1
                     group by substr(bmdm,1,6)) t1  on t0.xzqh =t1.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select  acl.f_get_bmdmdd(cjjg) xzqh, count(1) as surveil2
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and t.zt='2' and ywzl='2'
                     group by acl.f_get_bmdmdd(cjjg)) t6  on t0.xzqh =t6.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select acl.f_get_bmdmdd(cjjg) xzqh, count(1) as surveil3
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and (t.zt is null or t.zt<>'2') and ywzl='2'
                     group by acl.f_get_bmdmdd(cjjg)) t7  on t0.xzqh =t7.xzqh

        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select  acl.f_get_bmdmdd(cjjg) xzqh, count(1) as wt2
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and t.zt='2' and ywzl='1'
                     group by acl.f_get_bmdmdd(cjjg)) t16  on t0.xzqh =t16.xzqh
        --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
        left join (select acl.f_get_bmdmdd(cjjg) xzqh, count(1) as wt3
                     from xgt_vio_surveil_in t
                     where t.wfsj>=to_date(p_tjrqs, 'yyyy-mm-dd') and t.wfsj < to_date(p_tjrqz, 'yyyy-mm-dd')+1 and (t.zt is null or t.zt<>'2') and ywzl='1'
                     group by acl.f_get_bmdmdd(cjjg)) t17  on t0.xzqh =t17.xzqh;





         --锟斤拷锟斤拷锟斤拷锟斤拷
      --  left join(select acl.f_get_bmdmdd(t2.bmdm) xzqh,count(1) as qwgl2
      --              from qwgl_pb t1,acl_user t2
      --               where t1.pbrq>=to_date(p_tjrqs,'yyyy-mm-dd') and t1.pbrq<to_date(p_tjrqz,'yyyy-mm-dd')+1
      --               and t1.yhdm=t2.yhdm
       --              group by acl.f_get_bmdmdd(t2.bmdm))t26 on t0.xzqh=t26.xzqh

      -- order by bmdm;
    end if;
  end p_vio_tj_dd;


  end vio;

/
