CREATE package viocheck is

   procedure p_check_vioaqtk(v_jszh in varchar2, v_ret out varchar2);
   function f_get_xjxm(v_yhdm in varchar2) return varchar2;
   function f_get_bmmc(v_bmdm in varchar2) return varchar2;
end viocheck;

/
