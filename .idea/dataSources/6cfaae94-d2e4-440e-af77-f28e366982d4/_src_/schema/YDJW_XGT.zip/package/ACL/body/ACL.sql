CREATE package body acl is

  function f_get_bmdmdd(v_bmdm in varchar2) return varchar2 is
    v_ret                      varchar2(12);
    begin
      if substr(v_bmdm,1,6)='330302' or substr(v_bmdm,1,8)='33030050' then
        v_ret:=substr(v_bmdm,1,8);
      else
        v_ret:=substr(v_bmdm,1,6);
      end if;
      return(v_ret);
   exception when others then
      null;

 end f_get_bmdmdd;
end acl;

/
