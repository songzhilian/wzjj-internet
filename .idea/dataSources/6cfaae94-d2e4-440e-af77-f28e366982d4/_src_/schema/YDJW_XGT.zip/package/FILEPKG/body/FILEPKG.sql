CREATE package body filepkg is

 procedure p_get_tablename(v_tname in varchar2, v_cur_tname out varchar2) is
    i_days     number;
    i_daystd   number;
  begin
    select sysdate-kssj,tname||tindex,days into i_days,v_cur_tname,i_daystd from file_upload_config where tname=v_tname and zt='1';

    if i_days >i_daystd then

       select tname||tindex into v_cur_tname from file_upload_config where tname=v_tname and zt='0';
       update file_upload_config set jssj=sysdate,zt='0' where tname=v_tname and zt='1';
       update file_upload_config set kssj=sysdate,zt='1' where tname||tindex=v_cur_tname;
       commit;
    end if;

  end p_get_tablename;


  procedure p_move_block_99  is
    rec_upload               file_upload%rowtype;
    cursor cur1 is select * from file_upload where zt='0';
  begin
    open cur1;
    loop
      fetch cur1 into rec_upload;
      exit when cur1%notfound;
/*
        select count(1) into v_count from file_upload where ywlx=rec_upload.ywlx and ywlsh=rec_upload.ywlsh and filename=rec_upload.filename and zt='1';
        if v_count = 0 then
           insert into file_upload_block_99(blockid, fileid, blockidx, blocksize, data)
             select blockid, fileid, blockidx, blocksize, data from file_upload_block_03 where fileid=rec_upload.fileid;
           commit;
        end if ;
        */
        null;
    end loop;
    close cur1;
  end p_move_block_99;


    --锟斤拷锟斤拷block
  procedure p_clean_block is
    v_tindex              varchar2(32);
    v_count               number;
    rec_block             file_upload_block_01%rowtype;
    v_index               number:=1;
    type ref_cursor is ref cursor;
    cur1 ref_cursor;
    begin
       select count(*) into v_count from file_upload_config where tname='FileUploadBlock' and zt='0';
       if v_count > 0 then
          select tindex into v_tindex from file_upload_config where tname='FileUploadBlock' and zt='0';
          if v_tindex = '01' then
              open cur1 for select a.* from file_upload_block_01 a where exists(select null from xgt_file_upload b where zt='0'
              and a.fileid=b.fileid);
          end if;
          if v_tindex = '02' then
              open cur1 for select a.* from file_upload_block_02 a where exists(select null from xgt_file_upload b where zt='0'
              and a.fileid=b.fileid);
          end if;
               loop
               fetch cur1 into rec_block;
               exit when cur1%notfound;
                 begin
                    insert into file_upload_block_99(blockid, fileid, blockidx, blocksize, data)values
                    (rec_block.blockid,rec_block.fileid,rec_block.blockidx,rec_block.blocksize,rec_block.data);
                    if mod(v_index,1000)=0 then
                       commit;
                    end if ;
                    v_index:=v_index+1;
                    exception when others then
                        null;
                  end;
                 end loop;
               close cur1;
               commit;
               execute immediate 'truncate table file_upload_block_'||v_tindex;
       end if;
  end p_clean_block;


--清理sys_log_data
  procedure p_clean_syslog is
    i_days              number;
    v_tindex            varchar2(32);
  begin
    select sysdate-kssj,tindex into i_days,v_tindex from file_upload_config
     where tname='SysLogData' and zt='1';

    if i_days > 5 then --保留7天的日志
       --删除zt=0的另外个日志表的数据
       if v_tindex = '01' then
       --删除02的日志表
          execute immediate 'truncate table sys_log_data_02';
       end if;

       if v_tindex = '02' then
       --删除01的日志表
          execute immediate 'truncate table sys_log_data_01';
       end if;
    end if;

    select sysdate-kssj,tindex into i_days,v_tindex from file_upload_config
     where tname='SysLogOutData' and zt='1';

    if i_days > 3 then --保留7天的日志
       --删除zt=0的另外个日志表的数据
       if v_tindex = '01' then
       --删除02的日志表
          execute immediate 'truncate table sys_logout_data_02';
       end if;

       if v_tindex = '02' then
       --删除01的日志表
          execute immediate 'truncate table sys_logout_data_01';
       end if;
    end if;
  end p_clean_syslog;



end filepkg;

/
