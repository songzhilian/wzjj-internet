CREATE package aync is

  procedure p_aync_file_upload;
  procedure p_aync_file_data_fxc;


end aync;

/
