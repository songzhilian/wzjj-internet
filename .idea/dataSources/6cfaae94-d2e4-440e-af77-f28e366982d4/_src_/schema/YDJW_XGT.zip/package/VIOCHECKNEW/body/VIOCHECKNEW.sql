CREATE package body viochecknew is
procedure p_check_vioaqtk_new(v_jszh in varchar2, v_ret out varchar2) is
     rec_vioaqtk        xgt_vio_aqtk%rowtype;
     v_count          number;
     v_jg             varchar2(10);
     v_jgMsg          varchar2(1024);
      begin
      v_count:=0;
       select count(1) into v_count from xgt_vio_aqtk where sfzmhm=v_jszh;
       if v_count>0 then
         v_jg:='1';
          v_jgMsg:='该非机动车驾驶人于';
        select count(1) into v_count from xgt_vio_aqtk where sfzmhm=v_jszh and substr(ywlx,1,1)='1' ;
        if v_count>0 then
         for c in (
        select * into rec_vioaqtk from (
          select * from xgt_vio_aqtk where sfzmhm=v_jszh and substr(ywlx,1,1)='1' order by lsh desc )) loop
          v_count:=v_count+1;
          --where rownum<=1;
           v_jgMsg:=v_jgMsg||to_char(rec_vioaqtk.ffsj,'yyyy-mm-dd hh24:mi:ss')||'在'||rec_vioaqtk.ffdz
           ||'被'||viochecknew.f_get_bmmc(rec_vioaqtk.cjjg)||'辅警'||viochecknew.f_get_xjxm(rec_vioaqtk.yhdm)||'进行了劝导上牌;';
        end loop;
        end if;

          select count(1) into v_count from xgt_vio_aqtk where sfzmhm=v_jszh and substr(ywlx,2,1)='1';
        if v_count>0 then
         for c in (
           select * into rec_vioaqtk from (
           select * from xgt_vio_aqtk where sfzmhm=v_jszh and substr(ywlx,2,1)='1' order by lsh desc ))loop
          --where rownum<=1;
           v_jgMsg:=v_jgMsg||to_char(rec_vioaqtk.ffsj,'yyyy-mm-dd hh24:mi:ss')||'在'||rec_vioaqtk.ffdz
           ||'被'||viochecknew.f_get_bmmc(rec_vioaqtk.cjjg)||'辅警'||viochecknew.f_get_xjxm(rec_vioaqtk.yhdm)||'进行了劝导戴头盔;';
         end loop;
         end if;
         select count(1) into v_count from xgt_vio_aqtk where sfzmhm=v_jszh and substr(ywlx,3,1)='1';
         if v_count>0 then
          for c in (
           select * into rec_vioaqtk from (
            select * from xgt_vio_aqtk where sfzmhm=v_jszh and substr(ywlx,3,1)='1' order by lsh desc ))loop
         -- where rownum<=1;
           v_jgMsg:=v_jgMsg||to_char(rec_vioaqtk.ffsj,'yyyy-mm-dd hh24:mi:ss')||'在'||rec_vioaqtk.ffdz
           ||'被'||viochecknew.f_get_bmmc(rec_vioaqtk.cjjg)||'辅警'||viochecknew.f_get_xjxm(rec_vioaqtk.yhdm)||'进行了安全头盔发放登记;';
           end loop;
          end if;
          v_ret := '1'||v_jgMsg;
        end if;
  end p_check_vioaqtk_new;
  function f_get_xjxm(v_yhdm in varchar2) return varchar2 is
         v_ret        varchar2(12);
          xjxx        xgt_acl_user%rowtype;
          begin
            select * into xjxx from xgt_acl_user where yhdm=v_yhdm;
            v_ret:= xjxx.xm;
            return(v_ret);
          exception when others then
            null;
       end f_get_xjxm;
       function f_get_bmmc(v_bmdm in varchar2) return varchar2 is
         v_ret        varchar2(128);
          bmxx        acl_dept%rowtype;
          begin
            select * into bmxx from acl_dept where bmdm=v_bmdm;
            v_ret:= bmxx.bmjc;
            return(v_ret);
          exception when others then
            null;
       end f_get_bmmc;
end viochecknew;

/
