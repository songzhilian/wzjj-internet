CREATE package body p_sunland_tb   is
  -- Author  : SUNBIN
  -- Created : 2017/5/3 17:13:20
  -- Purpose :

---本过程是实现自动生成触发器
procedure SUNLAND_CREATE_TRI(p_tablename varchar2) is

s_tablename varchar2(100);
s_sql CLOB;
s_where varchar2(32767);
s_where_d varchar2(32767);
s_column_name varchar2(100);
s_data_type varchar2(100);
s_lx1 varchar2(100);
s_lx2 varchar2(100);
s_lx3 varchar2(100);
s_lx4 varchar2(100);
s_lx5 varchar2(100);
s_lx6 varchar2(100);
s_lx11 varchar2(100);
s_lx12 varchar2(100);
s_lx13 varchar2(100);
s_lx14 varchar2(100);
s_lx15 varchar2(100);
s_lx16 varchar2(100);
s_lx19 varchar2(100);
s_lx20 varchar2(100);

S_Exe_Sql_I CLOB;
S_Exe_Sql_D CLOB;
S_Exe_Sql_I1 clob;
S_Exe_Sql_D1 clob;
s_tri varchar2(20);
s_values CLOB;
cursor c0 is
 select COLUMN_NAME,DATA_TYPE from user_tab_columns where table_name=s_tablename ;

cursor c1 is
 select column_name,data_type from all_tab_columns where (owner,table_name,column_name) in (
 select cu.owner,cu.table_name,cu.column_name from user_cons_columns cu, user_constraints au where
 cu.constraint_name = au.constraint_name
 and au.constraint_type = 'P' and au.table_name = s_tablename);

begin
s_tablename:=upper(p_tablename);
select lx into s_lx1 from SUNLAND_TB_SET where xh=1;
select lx into s_lx2 from SUNLAND_TB_SET where xh=2;
select lx into s_lx3 from SUNLAND_TB_SET where xh=3;
select lx into s_lx4 from SUNLAND_TB_SET where xh=4;
select lx into s_lx5 from SUNLAND_TB_SET where xh=5;
select lx into s_lx6 from SUNLAND_TB_SET where xh=6;
select lx into s_lx11 from SUNLAND_TB_SET where xh=11;
select lx into s_lx12 from SUNLAND_TB_SET where xh=12;
select lx into s_lx13 from SUNLAND_TB_SET where xh=13;
select lx into s_lx14 from SUNLAND_TB_SET where xh=14;
select lx into s_lx15 from SUNLAND_TB_SET where xh=15;
select lx into s_lx16 from SUNLAND_TB_SET where xh=16;
select lx into s_lx19 from SUNLAND_TB_SET where xh=19;
select lx into s_lx20 from SUNLAND_TB_SET where xh=20;


open c0;
loop
  fetch c0 into s_column_name,s_data_type;
  exit when c0%notfound;
  S_Exe_Sql_I:= S_Exe_Sql_I||s_column_name||',';

   if s_data_type='VARCHAR2' or s_data_type='CHAR' or s_data_type='NVARCHAR2' then
       s_values:= s_values||s_lx11||':new.'||s_column_name||s_lx12;
   end if;
   if s_data_type='NUMBER' then
      s_values:=s_values||s_lx13||':new.'||s_column_name||s_lx14;

   end if;
   if s_data_type='DATE' then
      -- s_values:=s_values||s_lx15||':new.'||s_column_name||s_lx16;

       s_values:=s_values||s_lx19||'case when '||':new.'||s_column_name||' is null then '||''''||'NULL'||''''||' else '||s_lx15||':new.'||s_column_name||s_lx16;

   end if;

  end loop;
close c0;
S_Exe_Sql_I:=''''||'insert into '||s_tablename||'('||SUBSTR(S_Exe_Sql_I,1,LENGTH(S_Exe_Sql_I)-1)||')';
S_Exe_Sql_I:=S_Exe_Sql_I||' values ('||''''||SUBSTR(s_values,1,LENGTH(s_values)-5)||s_lx20||');';


   open c1;
   loop
   fetch c1 into s_column_name,s_data_type;
   exit when c1%notfound;
   if s_data_type='VARCHAR2' or s_data_type='CHAR' or s_data_type='NVARCHAR2' then
   s_where:=s_where||s_column_name||s_lx1||':new.'||s_column_name||s_lx2;
   s_where_d:=s_where_d||s_column_name||s_lx1||':old.'||s_column_name||s_lx2;
   end if;
   if s_data_type='NUMBER' then
    s_where:=s_where||s_column_name||s_lx3||':new.'||s_column_name||s_lx4;
     s_where_d:=s_where_d||s_column_name||s_lx3||':old.'||s_column_name||s_lx4;
    end if;
  if s_data_type='DATE' then

   s_where:=s_where||s_column_name||s_lx5||':new.'||s_column_name||s_lx6;
    s_where_d:=s_where_d||s_column_name||s_lx5||':old.'||s_column_name||s_lx6;

    end if;
   end loop;
   close c1;

 --S_Exe_Sql_I:=''''||'insert into '||s_tablename||' select * from '||s_tablename||'@dblink_out_to_in WHERE '||SUBSTR(s_where,1,LENGTH(s_where)-13)||');';

 S_Exe_Sql_D:=''''||'delete from '||s_tablename||' WHERE '||SUBSTR(s_where_d,1,LENGTH(s_where)-13)||');';
S_Exe_Sql_D1:=''''||'begin '||''''||'||'||substr(S_Exe_Sql_D,1,length(S_Exe_Sql_D)-2)||'||'||''''||';'||''''||'||';
S_Exe_Sql_I1:=substr(S_Exe_Sql_I,1,length(S_Exe_Sql_I)-2)||'||'||''''||'; end ;'||''''||');';

s_tri:='20170503';
s_sql:='create or replace trigger tri_'||s_tablename||s_tri
||
'
after insert or update or delete on '||s_tablename||
'
for each row
declare
begin
 if inserting then
   insert into SUNLAND_TB_w(xh,Exe_Sql)
   values(seq_exp_xh.nextval,'||S_Exe_Sql_I||
'
elsif updating then
   insert into SUNLAND_TB_w(xh,Exe_Sql)
   values(seq_exp_xh.nextval,'||S_Exe_Sql_D1||S_Exe_Sql_I1||
 '
 elsif deleting then
   insert into SUNLAND_TB_w(xh,Exe_Sql)
   values(seq_exp_xh.nextval,'||S_Exe_Sql_D||
'
end if;
end tri_'||s_tablename||s_tri||'; ';
EXECUTE IMMEDIATE S_SQL;
 --insert into AAA(Cjjgmc) values (s_sql);

end SUNLAND_CREATE_TRI;




  ----注意！！！ 本同步过程只在内网服务器上进行（由内网服务器建数据库链接到外网）
  --取外网（远程）数据，同步到内网，同一个表sunland_tb_w
  ------（如果采用了数据库同步，则无需执行本过程）
  ---采用JAVA 调用
  /*
  procedure p_w_to_n_tb is --外网到内网同步
    i_max_xh number;
    i_xh number;
    v_ErrorCode NUMBER;
    v_ErrorText VARCHAR2(200);
    cursor c1 is
    select xh from sunland_tb_w@sunland_ww where xh<=i_max_xh order by xh asc;
  begin
  ----把外网数据同步过来，sunland_tb_w 表
    begin
    select max(xh) into i_max_xh from sunland_tb_w@sunland_ww;
         EXCEPTION
        WHEN OTHERS THEN
        v_ErrorCode := SQLCODE;
        v_ErrorText := SUBSTR(SQLERRM, 1, 200);
        rollback;
         insert into SUNLAND_TB_err(xh,zxsj,err,ERR_CODE,lx)
         values(0,sysdate,v_ErrorText,v_ErrorCode,1);
         commit;
         return;
    end;
    open c1 ;
    loop
      fetch c1 into i_xh;
      exit when c1%notfound;
      begin
        insert into sunland_tb_w select * from sunland_tb_w@sunland_ww where xh=i_xh;
        delete from sunland_tb_w@sunland_ww where xh=i_xh;
        EXCEPTION
        WHEN OTHERS THEN
        v_ErrorCode := SQLCODE;
        v_ErrorText := SUBSTR(SQLERRM, 1, 200);
        rollback;
        insert into SUNLAND_TB_err(xh,zxsj,err,ERR_CODE,lx)
      values(i_xh,sysdate,v_ErrorText,v_ErrorCode,1);
      commit;
        exit;
      end;
      commit;
    end loop;
    close c1;
  end p_w_to_n_tb;

    ----注意！！！ 本同步过程只在内网服务器上进行（由内网服务器建数据库链接到外网）
      --取内网数据，同步到外网（远程），同一个表sunland_tb_n
  ------（如果采用了数据库同步，则无需执行本过程）
    ---采用JAVA 调用
  procedure p_n_to_w_tb is--内网网到外网同步
        i_max_xh number;
    i_xh number;
        v_ErrorCode NUMBER;
    v_ErrorText VARCHAR2(200);
    cursor c1 is
    select xh from sunland_tb_n where xh<=i_max_xh order by xh asc;
  begin
  ----把内网网数据同步到外网sunland_tb_n 表(@sunland_ww)
    begin
     select max(xh) into i_max_xh from sunland_tb_n;
     EXCEPTION
        WHEN OTHERS THEN
         v_ErrorCode := SQLCODE;
        v_ErrorText := SUBSTR(SQLERRM, 1, 200);
        rollback;
         insert into SUNLAND_TB_err(xh,zxsj,err,ERR_CODE,lx)
         values(0,sysdate,v_ErrorText,v_ErrorCode,1);
         commit;
        return;
     end;
    open c1 ;
    loop
      fetch c1 into i_xh;
      exit when c1%notfound;
      begin
        insert into sunland_tb_n@sunland_ww select * from sunland_tb_n where xh=i_xh;
        delete from sunland_tb_n where xh=i_xh;
        EXCEPTION
        WHEN OTHERS THEN
        v_ErrorCode := SQLCODE;
        v_ErrorText := SUBSTR(SQLERRM, 1, 200);
        insert into SUNLAND_TB_err(xh,zxsj,err,ERR_CODE,lx)
        values(i_xh,sysdate,v_ErrorText,v_ErrorCode,1);
      commit;
        rollback;
        exit;
      end;
      commit;
    end loop;
    close c1;
  end p_n_to_w_tb;


  --注意！ 本存储过程只在内网服务执行，实现把外网数据更新到内网
  procedure p_w_to_n_zx is --外网到内网执行
    i_max_xh number;
    i_xh number;
    s_exe_sql CLOB;
    v_ErrorCode NUMBER;
    v_ErrorText VARCHAR2(200);
    cursor c1 is
    select xh,exe_sql from sunland_tb_w where xh<=i_max_xh order by xh asc;
 begin
   select max(xh) into i_max_xh from sunland_tb_w;
    open c1;
    loop
      fetch c1 into i_xh,s_exe_sql;
      exit when c1%notfound;

      begin
      execute immediate s_exe_sql;
      delete from sunland_tb_w where xh=i_xh;
      EXCEPTION
      WHEN OTHERS THEN
        v_ErrorCode := SQLCODE;
        v_ErrorText := SUBSTR(SQLERRM, 1, 200);
       rollback;
      insert into SUNLAND_TB_err(xh,Exe_Sql,zxsj,err,ERR_CODE,lx)
      values(i_xh,s_exe_sql,sysdate,v_ErrorText,v_ErrorCode,2);
      end;
      commit;
    end loop;
    close c1;
    commit;
 end p_w_to_n_zx;
*/
    --注意！ 本存储过程只在外网服务执行，实现把内网数据更新到外网
 procedure p_n_to_w_zx IS --内网网到外网执行

 i_max_xh number;
    i_xh number;
    s_exe_sql CLOB;
    v_ErrorCode NUMBER;
    v_ErrorText VARCHAR2(200);
    cursor c1 is
    select xh,exe_sql from sunland_tb_n where xh<=i_max_xh and rownum < 50 order by xh desc;
 begin
   select max(xh) into i_max_xh from sunland_tb_n;
    open c1;
    loop
      fetch c1 into i_xh,s_exe_sql;
      exit when c1%notfound;
      begin
      execute immediate s_exe_sql;
     delete from sunland_tb_n where xh=i_xh;
      EXCEPTION
      WHEN OTHERS THEN
        v_ErrorCode := SQLCODE;
        v_ErrorText := SUBSTR(SQLERRM, 1, 200);
       insert into SUNLAND_TB_err(xh,Exe_Sql,zxsj,err,ERR_CODE,lx)
       values(i_xh,s_exe_sql,sysdate,v_ErrorText,v_ErrorCode,2);
      end;
      commit;
    end loop;
    close c1;
    commit;
 end p_n_to_w_zx;


end p_sunland_tb;

/
