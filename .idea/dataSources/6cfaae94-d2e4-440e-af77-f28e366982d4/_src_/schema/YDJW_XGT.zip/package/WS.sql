CREATE package ws is

  /**锟斤拷锟斤拷锟斤拷锟斤拷**/
  function f_get_wsjyw(wsbh in varchar2) return varchar2;
  function f_get_xzqhws(v_bmdm in varchar2, v_wslb in varchar2) return varchar2;

  --锟斤拷锟斤拷锟斤拷锟斤拷
  procedure p_get_wsbh(s_wslb in varchar2, i_wssl in number, s_bmdm in varchar2, s_yhdm in varchar2, s_wsbhs out varchar2) ;

  --锟斤拷锟斤拷锟斤拷锟斤拷
  procedure p_use_wsbh(s_wslb  in varchar2, s_wsbh in varchar2);

  --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
  procedure p_init_wsbh(s_wslb in varchar2,s_glbm in varchar2, i_ks in number, i_js in number);

 procedure p_get_wsbhNew(s_wslb  in varchar2, i_wssl  in number,  s_bmdm  in varchar2, s_yhdm  in varchar2, s_pdaid  in varchar2, s_wsbhs out varchar2);

 function f_get_xgtaqtkbh(v_bmdm in varchar2,v_yhdm in varchar2) return varchar2;


  function f_get_xgt_acd_sgbh(v_bmdm in varchar2) return varchar2;

  function f_get_xgt_vio_surveil_wsbh(v_bmdm in varchar2) return varchar2 ;
end ws;

/
