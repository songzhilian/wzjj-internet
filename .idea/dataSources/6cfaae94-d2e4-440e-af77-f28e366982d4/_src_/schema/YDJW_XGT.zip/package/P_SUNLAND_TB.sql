CREATE package p_sunland_tb Authid Current_User is

  -- Author  : SUNBIN
  -- Created : 2017/5/3 17:13:20
  -- Purpose :
 procedure SUNLAND_CREATE_TRI(p_tablename varchar2);
 -- procedure p_w_to_n_tb;--外网到内网同步
 -- procedure p_n_to_w_tb;--内网网到外网同步
 -- procedure p_w_to_n_zx;--外网到内网执行
  procedure p_n_to_w_zx;--内网网到外网执行

end p_sunland_tb;

/
