CREATE package body aync is

       --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       procedure p_aync_file_upload is
       rec_file_upload              file_upload%rowtype;
       v_count                      number;


       cursor c_file_upload is select * from file_upload where zt='1' and fileid > (select max(fileid) from xgt_file_upload);

       begin


         open c_file_upload;
         loop
           fetch c_file_upload into rec_file_upload;
           exit when c_file_upload%notfound;
                select count(1) into v_count from xgt_file_upload where fileid=rec_file_upload.fileid;
                if v_count = 0 then
                   insert into xgt_file_upload  (select * from file_upload where fileid=rec_file_upload.fileid);
                   commit;
                end if;
           end loop;

           close c_file_upload;
           exception when others then
                  dbms_output.put_line(sqlerrm);


       end;


       --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
       procedure p_aync_file_data_fxc is
         rec_file_data_fxc                file_upload_data_fxc%rowtype;
         v_count                          number;
         cursor c_file_data_fxc is select * from file_upload_data_fxc where fileid > (select max(fileid) from xgt_file_upload_data_fxc) or fileid > 0;
         begin
           open c_file_data_fxc;
           loop
             fetch c_file_data_fxc into rec_file_data_fxc;
             exit when c_file_data_fxc%notfound;
                  select count(1) into v_count from xgt_file_upload_data_fxc where fileid=rec_file_data_fxc.fileid;
                  if v_count = 0 then
                     insert into xgt_file_upload_data_fxc(fileid,data) (select fileid,data from file_upload_data_fxc where fileid=rec_file_data_fxc.fileid);
                     commit;
                  end if;
             end loop;

           close c_file_data_fxc;
           exception when others then
                  dbms_output.put_line(sqlerrm);
         end;


end aync;

/
