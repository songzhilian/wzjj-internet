CREATE package acl is

  function f_get_bmdmdd(v_bmdm in varchar2) return varchar2;

end acl;

/
