CREATE procedure p_check_upload_jysg(v_ywlx in varchar2, v_ywlsh in varchar2, v_filename in varchar2, v_result out varchar2 ) is
v_checklsh char(1);
v_count    number;
begin
  v_result:='0';--1正常；5-重复；6-业务流水号不存在


end p_check_upload_jysg;

/
