CREATE procedure p_ret_tasklock(vTaskId in varchar2)  is
   s_lock   varchar2(1);
   begin
     begin
         update sys_task set lockzt='0' where taskid=vTaskId;

     exception when others then
       null;
     end;
     commit;
end p_ret_tasklock;

/
