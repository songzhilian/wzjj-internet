CREATE procedure p_free_sys_log_data is
begin

       delete from sys_log_data_01 where rownum < 5000;
       commit;

end  p_free_sys_log_data;

/
