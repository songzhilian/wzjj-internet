CREATE procedure p_check_upload_fxc(v_ywlx in varchar2, v_ywlsh in varchar2, v_filename in varchar2, v_result out varchar2 ) is
v_checklsh char(1);
v_count    number;
begin
  v_result:='1';--1正常；5-重复；6-业务流水号不存在
  --先判断业务流水号
  v_checklsh:='1';
  if v_ywlx='3' then
    select count(1) into v_count from xgt_vio_surveil_in where lsh= to_number(v_ywlsh);
    if v_count=0 then
      v_checklsh:='0';
    end if;
  end if;

  if v_checklsh='0' then
    v_result:='6';--如果业务流水号不存在直接返回错误6
  else
     --否则继续校验是否已经上传成功
      v_count:=0;
      select count(1) into v_count from xgt_file_upload t1, xgt_file_upload_data_fxc t2 where ywlx=v_ywlx and ywlsh= to_number(v_ywlsh) and filename=v_filename and zt='1'
        and t1.fileid=t2.fileid and t2.data is not null;
      if v_count>0 then
        v_result:='5';--如果该张图片已经上传成功，则直接返回终端5
      end if;
  end if;

end p_check_upload_fxc;

/
