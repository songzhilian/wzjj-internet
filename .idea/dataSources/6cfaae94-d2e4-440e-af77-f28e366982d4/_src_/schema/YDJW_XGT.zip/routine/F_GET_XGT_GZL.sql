CREATE function f_get_xgt_gzl(s_yhdm varchar2,s_qsrq varchar2,s_zzrq varchar2,s_rqlx varchar2,s_xmlx varchar2) return
GZL_TABLETYPE pipelined as
--create or replace type "GZL_ROWTYPE" AS OBJECT(xmdl varchar2(10),xmdlmc varchar2(32),xmxl varchar2(10),xmxlmc varchar2(32),sl number);

s_ret GZL_ROWTYPE;
icount number;
s_qsrq_date date;
s_zzrq_date date;
begin
--select * from  table(f_get_gzl('031805',null,null,'4','1,2'))
if s_rqlx='1' then --锟斤拷锟斤拷
  s_qsrq_date:=to_date(to_char(sysdate,'yyyymmdd')||'00:00:00','yyyymmdd hh24:mi:ss');
  s_zzrq_date:=to_date(to_char(sysdate,'yyyymmdd')||'23:59:59','yyyymmdd hh24:mi:ss');
elsif s_rqlx='2' then  --锟斤拷锟斤拷
  s_qsrq_date:=to_date(to_char(sysdate - 1,'yyyymmdd')||'00:00:00','yyyymmdd hh24:mi:ss');
  s_zzrq_date:=to_date(to_char(sysdate - 1,'yyyymmdd')||'23:59:59','yyyymmdd hh24:mi:ss');
elsif s_rqlx='3' then--锟斤拷锟斤拷
 s_qsrq_date:=to_date(to_char(trunc(sysdate,'D')+1,'yyyymmdd')||'00:00:00','yyyymmdd hh24:mi:ss');
 s_zzrq_date:=to_date(to_char(trunc(sysdate,'D')+7,'yyyymmdd')||'23:59:59','yyyymmdd hh24:mi:ss');
elsif s_rqlx='4' then --锟斤拷锟斤拷
 s_qsrq_date:=to_date(to_char(trunc(sysdate,'MM'),'yyyymmdd')||'00:00:00','yyyymmdd hh24:mi:ss');
 s_zzrq_date:=to_date(to_char(LAST_DAY(sysdate),'yyyymmdd')||'23:59:59','yyyymmdd hh24:mi:ss');
else
s_qsrq_date:=to_date(s_qsrq,'yyyy-mm-dd');
s_zzrq_date:=to_date(s_zzrq||'23:59:59','yyyy-mm-dd hh24:mi:ss');
end if;



if instr(s_xmlx,'3')>0 then --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷

select count(1) into icount from xgt_vio_tuoche_in where zt='1' and ywzl='2' and yhdm=s_yhdm and wfsj>=s_qsrq_date and wfsj<=s_zzrq_date;
s_ret:=GZL_ROWTYPE('1','锟斤拷锟斤拷','3','锟斤拷锟斤拷',icount);
pipe row(s_ret);

end if;


if instr(s_xmlx,'1')>0 then --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
select count(1) into icount from xgt_vio_surveil_in where mjshzt<>'0' and  ywzl='1' and yhdm=s_yhdm and wfsj>=s_qsrq_date and wfsj<=s_zzrq_date;
s_ret:=GZL_ROWTYPE('1','锟斤拷锟斤拷','1','锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷',icount);
pipe row(s_ret);
end if;

if instr(s_xmlx,'2')>0 then --锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷
select count(1) into icount from xgt_vio_surveil_in where mjshzt='0'  and ywzl='1' and yhdm=s_yhdm and wfsj>=s_qsrq_date and wfsj<=s_zzrq_date;
if icount>0 then
s_ret:=GZL_ROWTYPE('1','锟斤拷锟斤拷','2','锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷',icount);
pipe row(s_ret);
end if;

end if;

return;
end f_get_xgt_gzl;

/
