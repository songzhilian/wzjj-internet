CREATE VIEW V_ACL_USER AS select yhdm,xm,bmdm from acl_user where zt='1'
/
