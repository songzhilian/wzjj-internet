CREATE VIEW SURVEIL_FILE_DATA AS select t1.lsh lsh, t2.fileid fileid, t2.zt zt  from  xgt_vio_surveil_in t1, xgt_file_upload t2
where t1.lsh = t2.ywlsh
/
